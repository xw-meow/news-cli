---
name: professional-daily-report
description: Use when the user asks for a blog-ready or newsletter-style Markdown daily report compiled from news-cli sources, especially when they mention daily reports, newsletters, summarized news, sections, or commentary
---

# Professional Daily Report

Generate a polished Markdown daily report / newsletter from `news get --json` output. The report is meant to be near-publishable: grouped by theme, with a lead, summaries, insights, and source stats.

## When to Use

- User asks for a "日报", "daily report", or "newsletter" from news sources
- User wants summarized, grouped, or commented news instead of raw headlines
- Output needs to be a single Markdown file ready for a blog or newsletter

## When NOT to Use

- User only wants raw headlines → run `news get` directly
- User wants real-time single-source output → no rewriting needed

## Output Format

At the start, ask the user:

> 你要生成 Markdown 日报，还是 HTML 大字报？

- Markdown → existing workflow, output `.md`
- HTML 大字报 → this new branch, output `.html`

## Quick Reference

| Field | Required | Default | Maps to |
|---|---|---|---|
| `topic` | yes | — | report title |
| `format` | no | `markdown` | `markdown` or `html` |
| `style` | no | 平衡 | tone (正式 / 轻松 / 深度 / 短讯) |
| `length` | no | 中 | `targetCount`: 短=5–7, 中=8–12, 长=13–20 |
| `keywords` | no | [] | filter + scoring |
| `date` | no | today (local) | `YYYY-MM-DD` filter |
| `sources` | no | auto-pick | `[{"name": "aibase"}]` |
| `outputFile` | no | `./daily/docs/daily-report-YYYY-MM-DD.{md|html}` | final path |

## Core Workflow

1. **Choose format**: ask whether to output Markdown or HTML 大字报
2. **Discover sources**: `node skills/professional-daily-report/scripts/list-sources.js`
3. **Create `./tmp/report-plan.json`** from the user's request
4. **Fetch**: `node skills/professional-daily-report/scripts/fetch-articles.js`
5. **Select**: `node skills/professional-daily-report/scripts/dedup-articles.js`
6. **Write `./tmp/report-content.md`** following the template
7. **Finalize**: `node skills/professional-daily-report/scripts/finalize-report.js`

After finalize, the report is written to `./daily/docs/daily-report-YYYY-MM-DD.{md,html}` and `./tmp` is deleted. Helper scripts auto-install `news-cli` if `news` is missing (repo build first, then global install).

## Step 0: Discover Sources

Run `list-sources.js`. It writes `./tmp/available-sources.json` with `available` and `recommended` arrays. Pick exactly 5 complementary sources from `recommended`; fall back to `available` if the topic is unusual. Use each source's default category by setting `category: null`.

## Step 1: Create `report-plan.json`

```json
{
  "topic": "AI 行业早报",
  "format": "html",
  "style": "正式",
  "length": "中",
  "keywords": ["大模型", "OpenAI"],
  "date": "2026-07-03",
  "outputFile": "docs/ai-daily.html",
  "sources": [
    {"name": "aibase"},
    {"name": "36kr"}
  ],
  "targetCount": 10
}
```

For Markdown output, set `"format": "markdown"` (or omit the field) and use `"outputFile": "docs/ai-daily.md"`.

## Step 2–3: Fetch and Select

Run `fetch-articles.js`, then `dedup-articles.js`. The default fetch limit is 50 articles per source. `dedup-articles.js` performs URL deduplication, title-similarity deduplication (≥ 85%), **today-only filtering**, keyword filtering, scoring, and truncation to `targetCount`.

## Step 4: Write the Report Body

Read `./tmp/selected-articles.json` and write `./tmp/report-content.md`.

**Template file (MUST follow):** `skills/professional-daily-report/reference/daily-report-template.md`

**Universal placeholder rule:** All `<<::identifier description>>` markers in the template must be replaced with real content, and the `<<::` / `>>` syntax must be removed completely. The text inside the marker is a hint for what belongs there and must not appear in the final output. This rule applies to any future templates that use the same syntax.

**Compliance rules:**

1. **Follow the template structure exactly.** Do not add, remove, rename, or reorder sections.
2. **Repeat the article group pattern** for each selected article:
   - Heading: `### [<标题>](<URL>)` — title is a clickable link to the original article
   - Summary paragraph
   - Insight sentence wrapped in `**粗体**` so it visually differs from the summary
   Group related articles under the same `## 分组标题`; start a new section when the theme changes.
3. **Keep exact Markdown formatting** for the title line, `## 导语`, and `## 今日来源`.
4. **Do not fabricate facts** beyond the article title/snippet.
5. **Match the requested `style`** in tone.
6. **Output only the report Markdown** to `./tmp/report-content.md`; no code fences, no explanations.

### HTML Branch

If `report-plan.json.format === "html"`, write `./tmp/report-content.html` instead of `./tmp/report-content.md`.

**Template file (MUST follow):** `skills/professional-daily-report/reference/daily-report-template.html`

**Rules:**
1. Replace every `<<::identifier description>>` placeholder with real content and remove the markers. Use only the placeholder identifiers that appear in `daily-report-template.html`.
2. Output a complete, self-contained HTML file with embedded CSS.
3. Article titles must be clickable bold `<a>` links to the original URL.
4. Insight sentences must be wrapped in `<strong>` so they stand out from the summary.
5. Use the A1 aged-newspaper style: paper texture, serif fonts, double-rule masthead, first-letter drop cap.
6. Do not fabricate facts beyond article title/snippet.
7. Match the requested `style` in tone.

## Step 5: Finalize

Run `finalize-report.js`. It reads `./tmp/report-content.{md,html}` according to `report-plan.json.format`, writes the final file to `./daily/docs/daily-report-YYYY-MM-DD.{md,html}` (or `outputFile`), and deletes `./tmp`.

## Failure Handling

- `news` missing: scripts auto-install; stop only if both repo-build and global install fail
- Single source fails: logged to stderr, workflow continues
- No articles after filtering: tell the user and suggest broader keywords or different sources
- Output file exists: overwrite without asking

## Common Mistakes

- Leaving `<<::...>>` placeholders in the final Markdown
- Leaving `<<::...>>` placeholders in the final HTML
- Forgetting to set `format: "html"` in the plan when generating HTML
- Skipping the today-only filter and including older articles
- Inventing facts not supported by the title/snippet
- Adding sections not present in the template
- Wrapping the Markdown body in triple backticks

## Helper Scripts

All scripts are plain Node.js ESM, no build step. See inline comments in `skills/professional-daily-report/scripts/` for detailed behavior.

- `list-sources.js` → `./tmp/available-sources.json`
- `fetch-articles.js` → `./tmp/raw-<source>.json`
- `dedup-articles.js` → `./tmp/selected-articles.json`
- `finalize-report.js` → `report-plan.json.outputFile`
